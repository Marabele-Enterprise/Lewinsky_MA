

<!-- Footer Starts -->
<div class="footer text-center spacer">
<!--p class="wowload flipInX"><a href="#"><i class="fa fa-facebook fa-2x"></i></a> <a href="#"><i class="fa fa-instagram fa-2x"></i></a> <a href="#"><i class="fa fa-twitter fa-2x"></i></a> <a href="#"><i class="fa fa-flickr fa-2x"></i></a> </p -->
	Copyright <?php date("Y"); ?> Nuve Med. All rights reserved.
</div>
<!-- # Footer Ends -->
<a href="#works" class="gototop "><i class="fa fa-angle-up  fa-3x"></i></a>





<!-- The Bootstrap Image Gallery lightbox, should be a child element of the document body -->
<div id="blueimp-gallery" class="blueimp-gallery blueimp-gallery-controls">
    <!-- The container for the modal slides -->
    <div class="slides"></div>
    <!-- Controls for the borderless lightbox -->
    <h3 class="title">Title</h3>
    <a class="prev">‹</a>
    <a class="next">›</a>
    <a class="close">×</a>
    <!-- The modal dialog, which will be used to wrap the lightbox content -->    
</div>



<!-- wow script -->
<script src="<?php echo URL; ?>public/assets/wow/wow.min.js"></script>


<!-- boostrap -->


<!-- jquery mobile -->
<script src="<?php echo URL; ?>public/assets/mobile/touchSwipe.min.js"></script>
<script src="<?php echo URL; ?>public/assets/respond/respond.js"></script>

<!-- gallery -->
<script src="<?php echo URL; ?>public/assets/gallery/jquery.blueimp-gallery.min.js"></script>

<!-- custom script -->
<script src="<?php echo URL; ?>public/assets/script.js"></script>

</body>
</html>